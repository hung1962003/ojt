# Select Test

In this exercise, we want to implement Adding and choose them based on runtime specific variables.

### Part 1: Select

**You have the following tasks:**

1. [task][Implement Select](testFood)

Implement the method `Result()` in the class `Exercise`. Make sure to follow the Bubble Sort algorithm exactly.